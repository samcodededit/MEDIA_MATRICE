/*********************************************************************************
  Nome applicazione:   es_matrice_dispari.cpp                                    *               
  Programmatore:  Villa Samuele					                                 *
  Descrizione:  -Leggere matrice da tastirea max 10 x 10						 *
				 -Stampare indice righe che finiscno con numero dispari          *
			     -Calcolare la media di ogni riga e salvare in un vettore		 *                   
**********************************************************************************/

/* direttive del preprocessore*/
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <ctype.h>
//DICHIARAZIONE COSTANTI//
#define max_row 10
#define max_column 10
/* 4996 si verifica quando il compilatore rileva una funzione o una variabile deprecata
   in passato documentata e considerata ufficiale il cui uso � attualmente sconsigliato
   a favore di una versione pi� recente */
#pragma warning(disable : 4996)

   /* main program: definire sempre che il main non possiede parametri  e ritorna un intero*/
int main(void)
{
	/* localizzazione: � una nazione nella quale � parlata una particolare lingua */
	setlocale(LC_ALL, "italian");

	char loop;

	do {

		system("cls");

		int mx[max_row][max_column] = { 0 }; int endr = 0; int endc = 0; int j = 0;
		float avgR[max_row] = { 0 };
		float avgC[max_column] = { 0 };

		printf("BENVENUTO! \n");

		printf("Il programma stamper� in output una matrice con ultimo valore dispari, calcoler� la media di ogni riga e di ogni colonna\n");
		printf("________________________________________________________________________________________________________________________\n");
		do
		{
			printf("\nInserire dimensione dalla matrice (righe e colonne): \n ");
			scanf_s("%d\t%d", &endr, &endc);
		} while ((endr < 0 || endr > 10) && (endc < 0 || endc > 10));


		for (int i = 0; i < endr; i++)
		{
			for (j = 0; j < endc; j++)
			{
				printf("Inserire valore della matrice in pos ( %d : %d) : ", i, j);
				scanf_s("%d", &mx[i][j]);
			}
		}
		printf("\n");
		printf("__________________________________\n");
		printf("MATRICE:\n");
		for (int i = 0; i < endr; i++)
		{
			for (int j = 0; j < endc; j++)
			{
				printf("%d\t", mx[i][j]);
				if (j == endc - 1)
				{
					if (mx[i][j] % 2 == 1)
					{
						printf("La RIGA E' DISPARI");
					}
				}
			}
			printf("\n");
		}
		printf("__________________________________\n");
		// MEDIA DI OGNI RIGA E COLONNA//
		for (int i = 0; i < endr; i++)
		{
			for (int j = 0; j < endc; j++)
			{
				avgR[i] = avgR[i] + mx[i][j];
				avgC[i] = avgC[i] + mx[j][i];
			}
			avgR[i] = avgR[i] / endr;
			avgC[i] = avgC[i] / endc;
		}
		printf("\n");
		printf("__________________________________\n");
		printf("MATRICE (media righe e colonne): \n");
		for (int i = 0; i < endr; i++)
		{
			for (int j = 0; j < endc; j++)
			{
				printf("%d\t", mx[i][j]);
			}
			printf("%f", avgR[i]);
			printf("\n");
		}
		printf("\n");
		for (int i = 0; i < endr; i++)
		{
			printf("%d)%f  ", i + 1, avgC[i]);
		}
		printf("\n__________________________________\n");
		printf("\n");
		printf("Premere [S] per ripetere .... premere un tasto per terminare\n");
		loop = _getche();
	} while (toupper(loop) == 'S');
	system("pause"); return(0);
}